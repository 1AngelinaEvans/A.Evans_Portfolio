"""

Quiz 1 problem 2

Create a script that examines a list of numbers

(for example, 2, 8, 64, 16, 32, 4) determines the second-largest number.

HINT: You can use mylist.sort() function to sort the array. 




"""


def secondLargest(mylist):

    sorted_list = mylist.sort()

    return mylist[-2]

