""""

Quiz 1 problem 3

Create a script that
examines a list of numbers (for example, 2, 8, 64, 16, 32, 4, 16, 8)
to determine whether it contains duplicates. The script should print a
meaningful result, such as “The list provided contains duplicate values”
or “The list provided does not contain duplicate values.” An optional
addition is to remove the duplicates from the list.

HINT: You can use list.count(value) to determine how many occurrences
of a value exists in a list.

"""

def duplicates(myList):

    duplicates = False

    for i in myList:

        if myList.count(i) > 1:

            duplicates = True

            myList.remove(i)
    

    if duplicates == True:
        return "This list contains duplicate values."
        
    else:  
        return "This list does not contain duplicate values."
            
