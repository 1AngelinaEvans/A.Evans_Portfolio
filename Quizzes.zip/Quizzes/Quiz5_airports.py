# Angelina Evans
# Geospatial Programming Quiz 5
import arcpy

# enter path
folder = "C:/Users/babyn/OneDrive/Desktop/Geo Programming/Quizzes/Quiz5/airports"

arcpy.env.workspace = folder

# view fields from airports.shp
fields = arcpy.ListFields("airports")
for field in fields:
    print(field.name)

# create a buffer field
arcpy.management.AddField("airports", "BUFFER", "LONG")
fields.append("BUFFER")

# Confirm that buffer field has been added
"BUFFER" in fields

# use search cursor to iterate through each row

spec_fields = ['FEATURE', 'TOT_ENP', 'BUFFER']
airports = "airports"

with arcpy.da.UpdateCursor(airports, spec_fields) as cursor:
        
    for row in cursor:
        
        # if feature of the row is airport: check the total enp.
        # if value is over 10k, then 15000 in
        # buffer field.if total enp is less than 1000, don't add a buffer
        # Otherwise, 10,000m buffer field.
        
        # Buffers are only for Airport and Sea Features
        try:
            if row[0] == "Airport":
                if row[1] > 10000:
                    row[2] = 15000
                elif row[1] > 1000 and row[1] <=10000:
                    row[2]=10000
        
        # if feature is sea base, check total enp. if value is over 1000,
        # add a 7,500m buffer. Otherwise, no buffer. 
        
            elif row[0] == "Seaplane Base":
                if row[1] >1000:
                    row[2] = 7500

        except NameError:
            print("Buffers can only be applied to Airport and Seaplane Base Features.")
            
            
        cursor.updateRow(row) 



# save as new shapefile
arcpy.FeatureClassToFeatureClass_conversion("airports", 
                                            folder, 
                                            "airport_buffers.shp")

# make sure buffer field is in new shapefile
fields2 = arcpy.ListFields("airport_buffers")
for field in fields2:
    print(field.name)


