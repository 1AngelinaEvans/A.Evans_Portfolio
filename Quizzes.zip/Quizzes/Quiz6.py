# Angelina Evans 
# Geospatial Programming
# Quiz 6

import arcpy

arcpy.env.workspace = "C:/Users/babyn/OneDrive/Desktop/Geo Programming/Quizzes/Quiz6/quiz6.gdb/quiz6/quiz6.gdb/quiz6.gdb"

print(arcpy.env.workspace)

# geodatabase
gdb = "C:/Users/babyn/OneDrive/Desktop/Geo Programming/Quizzes/Quiz6/quiz6.gdb"

# Block groups shp
bgs = "C:/Users/babyn/OneDrive/Desktop/Geo Programming/Quizzes/Quiz6/quiz6.gdb/quiz6.gdb/block_groups.shp"

# parks shp
parks = "C:/Users/babyn/OneDrive/Desktop/Geo Programming/Quizzes/Quiz6/quiz6.gdb/quiz6.gdb/parks.shp"

parksFC = "parks"

bgroupsFC = "block_groups"

fc = "parks"

fcFields = arcpy.ListFields(fc)
for field in fcFields:
    print(field.name)

blockgroups = "block_groups"

Polygon_Bfields = arcpy.ListFields(blockgroups)

arcpy.management.AddField(blockgroups, "PCT_OVERLAY", "LONG")
Polygon_Bfields.append("PCT_OVERLAY")

for field in Polygon_Bfields:
    print(field.name)

def calculatePercentAreaOfPolygonAInPolygonB(input_geodatabase, fcPolygonA, fcPolygonB, idFieldPolygonB
    # get the area of polygon A 
    rows = arcpy.SearchCursor(fcPolygonA) 
    for row in cursor:
        # calculate pct area
        pct_area = (row[0] / fcPolygonB.getValue(idFieldPolygonB))*100
        # add percent area to PCT_OVERLAY in polygonB
        fcPolygonB["PCT_OVERLAY"] = pct_area 
        cursor.updateRow(row) 
