# Angelina Evans
# Quiz 3


def plantStatus():
    threshhold = 0

    # get the inputs
    climate = input("Please enter a climate: ")
    temp_measurements = eval(input("Please a list of temperature measurements: "))
    temp_measurements = list(temp_measurements)

    # establish a new threshold depending on the climate type
    if climate == "Tropical":
        threshold = 30
    if climate == "Continental":
        threshold = 25
    else:
        threshold = 18

        
    # for loop that evaluates each element in temp_measurements
    for measurement in temp_measurements:
        if float(measurement) <= float(threshold):
            print("F")
        else:
            print("U")
                        
            
