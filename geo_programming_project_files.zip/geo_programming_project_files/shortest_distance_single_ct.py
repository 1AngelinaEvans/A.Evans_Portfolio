#!/usr/bin/env python
# coding: utf-8

# In[1]:


# Using OSMnx and NetworkX to calculate quickest routes to nearest cooling centers

# Code for evaluate distances from buildings for a single census tract.
# Citiation:
# Boeing, G. 2024. “Modeling and Analyzing Urban Networks and Amenities with OSMnx.” 
# Working paper. https://geoffboeing.com/publications/osmnx-paper/


# Steps:
# 1. Load census tract shapefile
# 2. Get building data for that census tract and load shapefile 
# 3. Generate graph network for census tract, (with or without surrounding census tracts). I will be loading all
    # census tracts within the greater Des Moines area.
# 4. Find the nearest cooling center for each building. 
# 5. Calculate driving distance from each building to the nearest cooling center. 
# 6. Explore results and save as csv. 

# Packages needed: matplotlib, shapely, osmnx, networkx, geopandas


# In[2]:


# pip install --upgrade pip
# pip install --upgrade matplotlib
# !pip install osmnx
# pip install shapely
# pip install networkx


# In[1]:


import osmnx as os
import geopandas as gpd
import pandas as pd
import matplotlib
import networkx as nx
import shapely
import pyproj
from shapely.geometry import Point
from shapely.ops import nearest_points


# In[2]:


# Building shapefile
file = r"C:\Users\babyn\OneDrive\Desktop\Geo Programming\Final Project\Data\dm_ct1\dm_ct1.shp"
# Read and plot the data
bldg = gpd.read_file(file)
bldg.head()


# In[3]:


bldg.plot()


# In[4]:


# Greater Des Moines area shapefile
file = r"C:\Users\babyn\OneDrive\Desktop\Senior_Project_Seminar\Project\Data\tracts_dsm_area_2.shp"
# Read and plot the data
dsm = gpd.read_file(file)
dsm.head()
dsm.plot()


# In[5]:


# Cooling centers shapefile
file2 = r"C:\Users\babyn\OneDrive\Desktop\Senior_Project_Seminar\Project\Data\cooling_centers\cooling_centers_geocoded.shp"
# Read and plot the data
cooling_centers = gpd.read_file(file2)
cooling_centers.head()
cooling_centers.plot()


# In[6]:


# projection for building shapefile, dsm shapefile and cooling center shapefile
dsm = dsm.to_crs('EPSG:26915')
bldg = bldg.to_crs('EPSG:26915')
cooling_centers = cooling_centers.to_crs('EPSG:26915')


# In[8]:


# Generate osmnx graph. This line will provide you with road networks from Open Street Map. 
# Combine all census tracts into one polygon to get road netorks for entire study area
polygon = dsm.unary_union.convex_hull
G = os.graph_from_polygon(polygon, network_type='drive', simplify=True)


# In[15]:


# View the road network
os.plot_graph(G)


# In[11]:


undirected_G = G.to_undirected()
connected_components = list(nx.connected_components(undirected_G))


# In[13]:


# Function to get the nearest node ID based on latitude and longitude
def get_nearest_node(lat, lon):
    return os.nearest_nodes(G, lon, lat,)


# In[18]:


# Get the node that is the nearest to each building
# Depending on the number of buildings, this may take several minutes 
for index, row in bldg.iterrows():
    centroid = row.geometry.centroid
    centroid_lon, centroid_lat = centroid.x, centroid.y
    nearest_node_id = get_nearest_node(centroid_lat, centroid_lon)
    bldg.loc[index, 'Nearest_Node_ID'] = nearest_node_id


# In[40]:


# Find the nearest cooling center to each building
# Iterate through each building row to evaluate each building
for idx, building in bldg.iterrows():
    nearest_center = None
    min_distance = float('inf')
    
    # Iterate through each cooling center row to find the closest one a building
    for cc_idx, center in cooling_centers.iterrows():
        distance = building.geometry.distance(center.geometry)
        if distance < min_distance:
            min_distance = distance
            nearest_center = center
    
    # Assign the nearest cooling center name to the building
    bldg.at[idx, 'Nearest_Cooling_Center'] = nearest_center['USER_name']
    bldg.at[idx, 'Cooling_Center_ID'] = nearest_center['Nearest_Node_ID']
    
# Now, 'buildings' DataFrame contains a new column 'Nearest_Cooling_Center' with the nearest cooling center name to each building

bldg.head(10)


# In[39]:


cooling_centers.head()


# In[46]:


# Iterate over each building
for idx, building in bldg.iterrows():
    # Get the ID of the specified nearest cooling center
    nearest_cc_id = building['Cooling_Center_ID']
    if isinstance(nearest_cc_id, (list, pd.Series)):
        nearest_cc_id = nearest_cc_id.iloc[0]  # Take the first value if there are multiple
    
    # Calculate shortest driving distance from the building to the specified nearest cooling center
    try:
        shortest_path_length = nx.shortest_path_length(G, source=building['Nearest_Node_ID'], target=nearest_cc_id, weight='length_mi')
        
        # Convert distance to minutes based on your travel speed
        # Assuming an average driving speed of 30 miles per hour
        driving_time_minutes = shortest_path_length / 30 * 60
        
        # Save the driving time in minutes to the specified nearest cooling center
        bldg.at[idx, 'Driving_Time_Minutes'] = driving_time_minutes
    except nx.NetworkXNoPath:
        print("No path found from building to specified nearest cooling center.")
        continue

bldg.head(10)


# In[51]:


# Average time?
avg_time = bldg['Driving_Time_Minutes'].mean()
print(avg_time)


# In[52]:


# Max time?
max_time = bldg['Driving_Time_Minutes'].max()
print(max_time)


# In[53]:


# Min time?
min_time = bldg['Driving_Time_Minutes'].min()
print(min_time)


# In[55]:


# save the results
bldg.to_csv(r"C:\Users\babyn\OneDrive\Desktop\Geo Programming\Final Project\bdlg_driving_times.csv")


# In[ ]:




