#!/usr/bin/env python
# coding: utf-8

# Using OSMnx and NetworkX to calculate quickest routes to nearest cooling centers

# Code for evaluate distances from census tract centroids.
# Citiation:
# Boeing, G. 2024. “Modeling and Analyzing Urban Networks and Amenities with OSMnx.” 
# Working paper. https://geoffboeing.com/publications/osmnx-paper/


# Steps:
# 1. Load Des Moines area shapefile 
# 2. Load cooling center centroid shapefile
# 3. Generate graph network for Des Moines area
# 4. Find the nearest cooling center for each census tract. 
# 5. Calculate driving distance from each census to the nearest cooling center. 
# 6. Explore results and save as csv. 


# pip install --upgrade pip
# pip install --upgrade matplotlib
# !pip install osmnx
# pip install shapely
# pip install networkx


import osmnx as os
import geopandas as gpd
import pandas as pd
import matplotlib
import networkx as nx
import shapely
import pyproj
from shapely.geometry import Point
from shapely.ops import nearest_points


# Greater Des Moines area shapefile
file = r"C:\Users\babyn\OneDrive\Desktop\Senior_Project_Seminar\Project\Data\tracts_dsm_area_2.shp"
# Read and plot the data
dsm = gpd.read_file(file)
dsm.head()
dsm.plot()


# Cooling centers shapefile
file2 = r"C:\Users\babyn\OneDrive\Desktop\Senior_Project_Seminar\Project\Data\cooling_centers\cooling_centers_geocoded.shp"
# Read and plot the data
cooling_centers = gpd.read_file(file2)
cooling_centers.head()
cooling_centers.plot()


# projection for dsm shapefile and cooling center shapefile
dsm = dsm.to_crs('EPSG:26915')
cooling_centers = cooling_centers.to_crs('EPSG:26915')



# Generate osmnx graph. This line will provide you with road networks from Open Street Map. 
# Combine all census tracts into one polygon to get road netorks for entire study area
polygon = dsm.unary_union.convex_hull
G = os.graph_from_polygon(polygon, network_type='drive', simplify=True)


# View the road network
os.plot_graph(G)


undirected_G = G.to_undirected()
connected_components = list(nx.connected_components(undirected_G))


# Function to get the nearest node ID based on latitude and longitude
def get_nearest_node(lat, lon):
    return os.nearest_nodes(G, lon, lat,)


# Get the node that is the nearest to each census tract centroid
for index, row in dsm.iterrows():
    centroid = row.geometry.centroid
    centroid_lon, centroid_lat = centroid.x, centroid.y
    nearest_node_id = get_nearest_node(centroid_lat, centroid_lon)
    dsm.loc[index, 'Nearest_Node_ID'] = nearest_node_id


# Get the node that is the nearest to each cooling center
for index, row in cooling_centers.iterrows():
    centroid = row.geometry.centroid
    centroid_lon, centroid_lat = centroid.x, centroid.y
    nearest_node_id = get_nearest_node(centroid_lat, centroid_lon)
    cooling_centers.loc[index, 'Cooling_Center_ID'] = nearest_node_id

# Iterate over each row in dsm
for index, row in dsm.iterrows():
    # storing nearest cooling center and minimum distance
    nearest_cc_info = None
    min_distance = float('inf')
    
    # Get the nearest node ID for the current row
    nearest_node = row['Nearest_Node_ID']
    
    # Iterate over each cooling center to find the nearest one
    for cc_idx, cc_row in cooling_centers.iterrows():
        try:
            # Calculate the distance from the nearest node to the cooling center
            distance = nx.shortest_path_length(G, source=nearest_node, target=cc_row['Cooling_Center_ID'], weight='length_mi')
            
            # Update nearest cooling center info if this center is closer than the previous one
            if distance < min_distance:
                min_distance = distance
                nearest_cc_info = {
                    'Cooling_Center_ID': cc_row['Cooling_Center_ID'],
                    'Cooling_Center_Name': cc_row['USER_name'],
                    'Distance_Minutes': distance / 30 * 60 
                }
        except nx.NetworkXNoPath:
            # Handle the case where no path exists between the nearest node and the cooling center
            print(f"No path found from nearest node {nearest_node} to cooling center {cc_row['Cooling_Center_ID']}.")
            continue
    
    # Add nearest cooling center info to dsm
    if nearest_cc_info:
        dsm.at[index, 'Nearest_cc'] = nearest_cc_info['Cooling_Center_Name']
        dsm.at[index, 'Nearest_cc_ID'] = nearest_cc_info['Cooling_Center_ID']
        dsm.at[index, 'Distance_Minutes'] = nearest_cc_info['Distance_Minutes']


dsm.head(10)


# Average time?
avg_time = dsm['Distance_Minutes'].mean()
print(avg_time)


# Max time?
max_time = dsm['Distance_Minutes'].max()
print(max_time)


# Min time?
min_time = dsm['Distance_Minutes'].min()
print(min_time)


cooling_centers.head()


cooling_centers.head()



dsm.head()



# save the results
dsm.to_csv(r"C:\Users\babyn\OneDrive\Desktop\Geo Programming\Final Project\dsm_driving_times.csv")



