
# Object Oriented Progamming 
# This file contains a Point class definition.



# A Point class should have at least at least two spatial attributes, x and y, to represent coordinates of a point. 
# calDis() is a method used to calculate the distance between 2 points.


# great_circle() is a method that uses the Great Circle Distance Formula.
# This formula computes the shortest distance path of two points on the surface of a sphere.


import math
from math import radians, degrees, sin, cos, asin, acos, sqrt


class Point:
    
    def __init__(self,x=0.0,y=0.0):
        self.x=x
        self.y=y

    def calDis(self,point):
        return math.sqrt((self.x-point.x)**2+(self.y-point.y)**2)

    def great_circle(self,point):
        self.x, self.y, point.x, point.y = map(radians, [self.x, self.y, point.x, point.y])

        
        return 6371 * (
            acos(sin(self.y) * sin(point.y) + cos(self.y) * cos(point.y) * cos(self.x - point.x)))
